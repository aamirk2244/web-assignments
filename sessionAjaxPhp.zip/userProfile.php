<?php
   session_start();
if (isset($_POST['submit']))
{
    $_SESSION['login'] = False;
    echo '<script>alert("Successfully Logged Out !!")</script>';
    exit();


}
    
   if(isset($_SESSION['login']) && $_SESSION['login'] == True)
   {



    echo 'you are logged in sucessfully  ';
    echo "<br>";
    echo "your User name is " . $_SESSION['name'];
    echo "<br>";
   
    echo "your Email  is " . $_SESSION['email'];
    echo "<br>";
   
    echo "your password is " . $_SESSION['password'];
    echo "<br>";
?>
    <form action="userProfile.php" method = "post">
    <input type="submit" value = "Log Out" name = "submit" style= "color:red;">


    </form>
<?php

            // if(isset($_COOKIE["city"])){
            //     echo "city : " . $_COOKIE["city"];
            // } 
            // else
            // {
            //     echo "Welcome guest! We encourage you to explore different sections!";
            // }

                            // echo '<script>alert("Good job aamir you are logged in !!")</script>'
    }
   else
   {

    echo 'Kindly log in first';
    exit();
            
    // echo '<script>alert("Login first bro !!")</script>';

   }





?>