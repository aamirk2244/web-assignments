<?php
    session_start();

    $_SESSION['login'] = False;              // i.e this user is not loged in yet


    require "db.php";
	if($_POST['password'] == '')                    // it means "More probably" this request is send by an event of onchange, so let's only fin the email
    {
        $sql="SELECT * FROM users WHERE emailAddress = '".$_POST['email']."'";
        $result = mysqli_query($conn,$sql);
   
        
        if(mysqli_num_rows($result) == 0)          // it means that the email not found
        {
            echo 'dummyText';                                // this text will be sent back to validateEmail function
        }
        else
        {
            echo $_POST['email'];                      // if row count in > 0 it means this email founded, return back this email
        }
        mysqli_close($conn);

            
    }
    else                          // i.e  when button clicked of login
    {
        

        $sql="SELECT * FROM users WHERE emailAddress = '".$_POST['email']."' and pass = '".$_POST['password']. "';";
        $result = mysqli_query($conn,$sql);
        $row = mysqli_fetch_array($result);
       
        if(mysqli_num_rows($result) == 0)          // it means that the email not found and password
        {
            echo 'notPass';                                // this text will be sent back to validateEmail function, hence the password in incorrect
        }
        else
        {

            $_SESSION['name'] = $row['fullName'];               // storing session variables for each user
            $_SESSION['email'] = $_POST['email'];
        
            $_SESSION['password'] = $_POST['password'];
            $_SESSION['login'] = True;              // i.e this user  loged in
        


            // alert('Login success');
            echo "<";                       //<script> location.href='http://localhost/test/sessions/userProfile.php'; </script>          // login successfull, redirect to another page
        }
        // mysqli_close($conn);



    }
    


?>