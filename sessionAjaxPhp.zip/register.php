<?php
        // echo '<script>alert("Reached here!!")</script>';
        // require 'db.php';                // connecting to database
        
        
        try{
            $conn = new PDO('mysql:host=localhost;dbname=agroculture;', 'aamir', '');
        
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $query = "INSERT INTO users( fullName, emailAddress, city, country, pass)VALUES ( '$_POST[name]', '$_POST[email]', '$_POST[city]', '$_POST[country]', '$_POST[password]');";
            $conn->exec($query);
            echo '<script>alert("Sign Up Successfull !!")</script>';

            setcookie('city', $_POST['city'], time() + (86400 * 30), "/"); // 86400 = 1 day        // means cookies will remain for 30 days. in the parent(base) directory 
            setcookie('country', $_POST['country'], time() + (86400 * 30), "/"); // 86400 = 1 day        // means cookies will remain for 30 days. in the parent(base) directory 
            // each user will have and see its own cookies when this website is deployed
            // since I am working on local machine therefore the last signed up user's cookies will be saved on this machine , i.e the previous will be override because of same name
            

        }catch(PDOException $e){
            echo 'Connection failed !! Sorry bro'. $e->getMessage();
            echo '<script>alert("Invalid Fields!!")</script>';

        }


 ?>